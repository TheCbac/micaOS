/***************************************************************************
*                                       MICA
* File: `$INSTANCE_NAME`.c
* Workspace: micaCompnents
* Project Name: libMica
* Version: v1.0
* Author: Craig Cheney
*
* Brief:
*   API for contolling dual Hbridge motors
* 
* Authors:
*   Craig Cheney
*
* Change Log:
*   2018.04.10 CC - Document created
********************************************************************************/
#include "`$INSTANCE_NAME`.h"

/*******************************************************************************
* Function Name: `$INSTANCE_NAME`_Write()
********************************************************************************
* Summary:
*   Sets the state of the LED control register
*
* Parameters:
*   uint8 State - The new state mask to write to the control register.
*
* Return:
*   uint8: Value of the control register after it was written. 
*
*******************************************************************************/


/* [] END OF FILE */
