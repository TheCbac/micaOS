/***************************************************************************
*                                       MICA
* File:  `$INSTANCE_NAME`.h
* Workspace: micaCompnents
* Project Name: libMica
* Version: v1.0
* Author: Craig Cheney
*
* Brief:
*   Definition for the H-bridge controller
* 
* Authors:
*   Craig Cheney
*
* Change Log:
*   2018.03.03 CC - Document created
********************************************************************************/
/* Header Guard */
#ifndef `$INSTANCE_NAME`_H
    #define `$INSTANCE_NAME`_H
    /***************************************
    * Macro Definitions
    ***************************************/
    #define `$INSTANCE_NAME`_FORWARD          (0b01u)
    #define `$INSTANCE_NAME`_BACKWARD         (0b00u)
    #define `$INSTANCE_NAME`_EN               (1u << 2u)

    #define `$INSTANCE_NAME`_M1_SHIFT       (0u)
    #define `$INSTANCE_NAME`_M2_SHIFT      (4u)

    #define `$INSTANCE_NAME`_M1_FORWARD     (`$INSTANCE_NAME`_FORWARD  << `$INSTANCE_NAME`_M1_SHIFT)
    #define `$INSTANCE_NAME`_M1_BACKWARD    (`$INSTANCE_NAME`_BACKWARD << `$INSTANCE_NAME`_M1_SHIFT)
    #define `$INSTANCE_NAME`_M1_EN          (`$INSTANCE_NAME`_EN       << `$INSTANCE_NAME`_M1_SHIFT)
    
    #define `$INSTANCE_NAME`_M2_FORWARD     (`$INSTANCE_NAME`_FORWARD  << `$INSTANCE_NAME`_M2_SHIFT)
    #define `$INSTANCE_NAME`_M2_BACKWARD    (`$INSTANCE_NAME`_BACKWARD << `$INSTANCE_NAME`_M2_SHIFT)
    #define `$INSTANCE_NAME`_M2_EN          (`$INSTANCE_NAME`_EN       << `$INSTANCE_NAME`_M2_SHIFT)
    /***************************************
    * Enumerated Types
    ***************************************/
    /* The possible directions*/
    typedef enum{
        `$INSTANCE_NAME`_DIRECTION_FORWARD,
        `$INSTANCE_NAME`_DIRECTION_BACKWARD,
        `$INSTANCE_NAME`_DIRECTION_CW,
        `$INSTANCE_NAME`_DIRECTION_CCW
    } `$INSTANCE_NAME`_DIRECTION_T;
    /***************************************
    * Structures
    ***************************************/
    /* Contains the speed of the motors */
    typedef stuct{
        int16 leftSpeed;
        int16 rightSpeed;
    } `$INSTANCE_NAME`_MOTOR_T; 
    /***************************************
    * Function Prototype
    ***************************************/
    void `$INSTANCE_NAME`_M1_WriteSpeed(int16 speed);
    void `$INSTANCE_NAME`_M2_WriteSpeed(int16 speed);
    void `$INSTANCE_NAME`_WriteSpeed(`$INSTANCE_NAME`_MOTOR_T* motors);
    `$INSTANCE_NAME`_MOTOR_T `$INSTANCE_NAME`_GetSpeed(void);
    void `$INSTANCE_NAME`_Move(`$INSTANCE_NAME`_DIRECTION_T direction, int16 speed);

#endif /* `$INSTANCE_NAME`_H */

/* [] END OF FILE */
